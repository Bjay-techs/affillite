<div>
        @include('home.include.user-base')


 <div class="breadcrumb-section">
     <div class="container">
         <div class="row">
             <div class="col-lg-12">
                 <div class="breadcrumb-text">
                     <h2>About Us</h2>
                     <p>Afonete is a unique innovative a next generation affiliate
                         system, aims to connecting companies are sure to reach the
                         right audience with clients and where we help millions of
                         people transform their lives that can benefit each other of
                         happy customers wanting to gain access to these amazing
                         platforms.</p>
                     
                 </div>
             </div>
         </div>
     </div>
 </div>
 <!-- Breadcrumb Section End -->

 <!-- About Us Page Section Begin -->
 <section class="aboutus-page-section spad">
     <div class="container">
         <div class="about-page-text">
             <div class="row">
                 <div class="col-lg-6">
                     <div class="ap-title">
                        
                         <h3>WHAT WE DO</h3>
                         <p>
                             Easy and best way to get yourself to the top of other billionaires
                             ,no investments what you need is only courage and commitment MUHAHE
                             is the best business solution for those who need to strengthen more their
                             businesses for it helps them while marketing their products, provide a quick
                             free delivery and provide great services at a lower price to everyone..
                         </p>
                         <p class="paragraph">We are combining with traditional marketing,
                             social media marketing and affiliate marketing opportunity for
                             promoting your product and service. that helps to provide
                             high levels of residual income for its all affiliate members.
                             We help you spread potential information to everyone,
                             anywhere all over the world. </p>
                     </div>
                 </div>

                 <div class="col-lg-5 offset-lg-1">
                     <ul class="ap-services">
                         <img src="assets/front/img/sm-banner1.jpg" alt="fail">
                     </ul>
                 </div>
                 <div class="col-lg-12">
                     <div class="ap-title">
                         <!-- font-size: 44px;
	color: #19191a;
	margin-bottom: 18px; -->
                         <h3 style="font-size:20px;margin-bottom: 18px;">A fonete have created a unique solutions system
                             for global community of people who love innovative technologies, blockchain technologies
                             and opened access for all people to benefit from a system we can implement
                             future innovations today which just<br> a few years ago was only accessible
                             for big companies.</h3>

                     </div>
                 </div>
             </div>
         </div>
 </section>
 
@include('home.include.footer')
 </div>