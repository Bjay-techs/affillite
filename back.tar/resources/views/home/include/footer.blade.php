<!-- Footer Section Begin -->
<footer class="footer-section">
  <div class="container">
    <div class="row">
      <div class="col-lg-4">
        <div class="ft-about" style="color:white">
          <p style="color:white">We inspire and reach millions of travelers across 90 local websites</p>
          <div class="fa-social">
            <!-- Social media icons here -->
          </div>
        </div>
      </div>
      <div class="col-lg-3 offset-lg-1">
        <div class="ft-contact">
          <h6 style="color:white">Locations & Contacts</h6>
          <table class="ft-location" style="color:white">
            <thead>
              <!-- Table header here -->
            </thead>
            <tbody>
              <tr>
                <td>Suede:</td>
                <td>+112456347647</td>
              </tr>
              <tr>
                <td>Japan:</td>
                <td>+7834647647</td>
              </tr>
              <tr>
                <td>South African:</td>
                <td>+34284643646</td>
              </tr>
              <tr>
                <td>USA:</td>
                <td>+18448457647</td>
              </tr>
              <tr>
                <td>Kenya:</td>
                <td>+334078347647</td>
              </tr>
              <tr>
                <td>Rwanda:</td>
                <td>+25078347647</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="col-lg-3 offset-lg-1">
        <div class="ft-newsletter">
          <h6 style="color:white">New latest</h6>
          <p style="color:white">Get the latest updates and offers.</p>
          <!-- Newsletter subscription form here -->
        </div>
      </div>
    </div>
  </div>
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <div class="co-text">
          <p style="color:white">
            &copy; <script>document.write(new Date().getFullYear());</script> Marathon LTD <i class="fa fa-heart" aria-hidden="true"></i> All rights reserved
          </p>
        </div>
      </div>
    </div>
  </div>
</footer>
<!-- Footer Section End -->

<!-- JS Plugins -->
<script src="{{asset('assets/front/js/jquery-3.3.1.min.js')}}"></script>
<script src="{{asset('assets/front/js/bootstrap.min.js')}}"></script>
<script src="{{asset('assets/front/js/owl.carousel.min.js')}}"></script>
<script src="{{asset('assets/front/js/main.js')}}"></script>
<script src="{{asset('assets/front/js/jquery-migrate-3.0.1.min.js')}}"></script>
<script src="{{asset('assets/front/js/jquery.stellar.min.js')}}"></script>
<script src="{{asset('assets/front/js/jquery.waypoints.min.js')}}"></script>
<script src="{{asset('assets/front/js/jquery.animateNumber.min.js')}}"></script>
<script src="{{asset('assets/front/js/aos.js')}}"></script>
<script src="{{asset('assets/front/js/slick.min.js')}}"></script>
<script src="{{asset('assets/front/js/mainn.js')}}"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
