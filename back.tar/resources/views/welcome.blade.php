<div style="width: 100%;">

    @include('home.include.user-base')

    {{-- <div id="overlayer"></div>
    <div class="loader">
        <div class="spinner-border text-primary" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div> --}}
    <!-- start of banner -->
    <!-- Hero Section Begin -->
    <section class="hero-section">
        <style>



        </style>
        <div class="hero-slider owl-carousel">
            <div class="hs-item set-bg" data-setbg="{{asset('assets/front/img/hero/big-banner2.jpg')}}">
                <div class="col hero-text">
                    <h1>Join Muhahe<br> Affiliate today</h1>
                    <p> All in one, innovator web3 and blockchain technology and </br> The platform for success-minded
                        people</p>
                    .<p> <a href="#" class=" primary-btn">I Want To Hire</a>
                        <a href="#" class=" info-btn">I Want To Work</a>
                    </p>
                </div>
            </div>
            <div class="hs-item set-bg" data-setbg="{{asset('assets/front/img/hero/big-banner3.jpg')}}">
                <div class="col hero-text">


                    <p class="float-right" id="afo">Afonete have created unique innovativeaffiliate <br>
                        platform solutions for global community of<br> people who
                        love innovative technologies, web3,<br> blockchain
                        technologies and opened access<br> for all people to
                        benefit from a system can implement<br> future
                        innovations todaywhich just a few years <br>ago
                        was only accessible for big companies.
                    </p>

                </div>
            </div>



    </section>
    <!-- Hero Section End -->
    <!-- end of banner -->


    <div class="responsive">



        <!-- START OF VIDEO SLIDER -->

        <!-- row -->
        <div class="slide-row">

            <!-- section title -->

            <div class="container">
                <div class="sections-tittle">
                    <div class="responsive rep">
                        <p>Many people lose more money for bundle/mbs <br>internet without generate even
                            $0.1 still We all spend <br>a LOT of time online,? Change your mind this is your <br>way You
                            can earn money $10 per day (dollar Bitcoin,<br> or usdt) by doing the things you
                            love online.Turn Your<br> Time Into Money.<br>
                        </p>
                    </div>
                    <center>
                        <div class="responsive rep1">
                            <p>Many Peaple lose more money for bundle/mbs internet without generate even
                                $0.1 still We all spend a LOT of <br>time online,? Change your
                                mind this is your way You can earn money $10 per day
                                (dollar Bitcoin, or usdt) by doing <br>the things you
                                love online.Turn Your Time Into Money.<br>
                            </p>
                        </div>
                    </center>

                    <div class=" sections-navs col-10">

                        <center>


                            </ul>
                    </div>
                </div>
                </center>
                <style>

                </style>

                <div class="image img ">
                    <img src="{{asset('assets/front/img/aff2-small.jpg')}}" alt="">

                </div>
                <div class="sections-navs">
                    <div id="mission">
                        <ul class="sections-tabs-navs col-12 tabs-navs">
                            <li>
                                <p>Get rewards/money for watching videos, shopping online,
                                    or signing up for exciting services</p>
                            </li>
                            <li>
                                <p>Earn anywhere you are even your home get money</p>
                            </li>
                            <li>
                                <p>Get money just for using social media!</p>
                            </li>
                            <li>
                                <p>Earn money for simple just click viewing ads </p>
                            </li>
                            <li>
                                <p>Earn crypto by playing fun games online.</p>
                            </li>
                            <li>
                                <p>Get rewards for referral people</p>
                            </li>
                            <a href="" class=" info-btn">Sign up & start earning</a>
                        </ul>
                    </div>

                </div>
            </div>
            <div class="sections-navs">
                <div class="missi" id="missi">
                    <ul class=" sections-tabs-navs col-12 tabs-navs">
                        <li>
                            <p>Get rewards/money for watching videos, shopping online,
                                or signing up for exciting services</p>
                        </li>
                        <li>
                            <p>Earn anywhere you are even your home get money</p>
                        </li>
                        <li>
                            <p>Get money just for using social media!</p>
                        </li>
                        <li>
                            <p>Earn money for simple just click viewing ads </p>
                        </li>
                        <li>
                            <p>Earn crypto by playing fun games online.</p>
                        </li>
                        <li>
                            <p>Get rewards for referral people</p>
                        </li>
                        <a href="" class=" info-btn">Sign up & start earning</a>
                    </ul>
                </div>

            </div>
        </div>

    </div>
    <!-- /section title -->


    <!-- sliddings tabs & slick -->
</div>
<br>
<!-- /row -->

<!-- END OF VIDEO SLIDER -->
<!-- Hero Section Begin -->

<!-- About Us Page Section Begin -->
<section class="aboutus-page-section spad">
    <div class="container-fluid ">
        <div class="about-page-text">
            <center>
                <h3>DO YOU WANT TO LIVE YOUR DREAMS?</h3>
            </center>
            <div class="sections-title row ">


                <center>
                    <p id="story">Our story began with an inner desire to change the world while creating a
                        fair opportunity for all individuals involved right now </p>
                </center>
                <div class=" sections-dream  row" id="do">
                    <ul class="sections-tabs-navs col-12 tabs-navs">
                        <li>
                            <p>Earn from your mbs/internet used to $5 for every task you participate in.</p>
                            <p>Get reward 100 000 projects/client uploaded </p>
                        </li>
                        <li>
                            <p>Get lifetime passive income </p>
                        </li>
                        <li>
                            <p>Free space room shop </p>
                        </li>
                        <li>
                            <p>Get 15% directs projects Uploaded</p>
                        </li>
                        <li>
                            <p>The buying and selling of products and services online.</p>
                        </li><br>
                        <a href="#" class=" primary-btn"> Do You want to sign up?</a><br><br>

                        <a href="" class=" info-btn">yes , I'd like to sign up</a>
                    </ul>
                </div>
                <div class=" image col " id="im2">
                    <ul>
                        <img src=" {{asset('assets/front/img/dream.jpg')}}" alt="">

                    </ul>
                </div>
            </div>

        </div>

    </div>
</section>

<!-- About Us Page Section End -->

<!-- Video Section Begin -->

<!-- sergr -->
<div class="well" style="margin-top:-102px">
    <div class="site-wrap">
        <div class="site-section first-section">
            <div class="container">

                <div class="row border-responsive bb1">
                    <div class="col-md-2 col-lg-2 mb-6 mb-lg-0 " data-aos="fade-up" data-aos-delay=""></div>


                    <div class="col" data-aos="fade-up" data-aos-delay="">
                        <div class="text-center">
                            <span
                                class="flaticon-money-bag-with-dollar-symbol display-4 d-block mb-3 text-primary"></span>
                            <h3 class="text-uppercase h4">sign up</h3>
                            <p> Feel free to join us, members from all countries are allowed.
                                Registration is absolute free </p>
                        </div>
                    </div>

                    <div class="col" data-aos="fade-up" data-aos-delay="">
                        <div class="text-center">
                            <span
                                class="flaticon-money-bag-with-dollar-symbol display-4 d-block mb-3 text-primary"></span>
                            <h3 class="text-uppercase h4 mb-3">EARN</h3>
                            <p>At afonete is unique platform you can earn option you wantsimple task ,click
                                views,
                                watch videoreferring new members completing offer</p>
                        </div>
                    </div>
                    <div class="col" data-aos="fade-up" data-aos-delay="">
                        <div class="text-center">
                            <span
                                class="flaticon-money-bag-with-dollar-symbol display-4 d-block mb-3 text-primary"></span>
                            <h3 class="text-uppercase h4 mb-3">CASHOUT</h3>

                            <p>Cashout your earn Mobile money perfect money Cash cheaper</p>
                        </div>
                    </div>
                    <div class="col" data-aos="fade-up" data-aos-delay="">
                        <div class="text-center">
                            <span
                                class="flaticon-money-bag-with-dollar-symbol display-4 d-block mb-3 text-primary"></span>
                            <h3 class="text-uppercase h4 mb-3">ONLINE SHOP</h3>
                            <p>Online shop Service companies Social media
                                br user Business service( software, Booking hote/ airticket).</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- serge end -->

<!-- <section class="video-section co-lg-5 ">
        <div class="container">
            <div class="row">
                <div class="col-3">
                    
                    <i class="fa fa-user-circle" aria-hidden="true"></i>
                    <p>SIGN UP Feel free to join us, members from all countries are allowed. 
                        Registration is absolute free </p>
                </div>
                <div class="col-3">
                    <p>At afonete is unique platform you can earn option you wantsimple task ,click views,
                     watch videoreferring new members completing offer</p>
                </div>
                <div class="col-3">
                    <p>Cashout  your earn Mobile money perfect moneyCashcheaper </p>
                </div>
                <div class=" col-3">
                    <p>Online shop Service companies Social media  
                       br userBusiness service( software, Booking hote/ airticket). 
</p>
                </div>
            </div>
        </div>
    </section> -->
<!-- Video Section End -->

<br>
<!-- START OF COUNTER NUMBER -->

<div class="well ">
    <div class="site-wrap">
        <div class="site-section section-counter"></div>
        <div class="site-section first-section">
            <div class="container">
                <div class="row mb-2">
                    <div class="col-md-12 text-center" data-aos="fade"> <br>
                        <h2 class="site-section-heading text-uppercase text-center font-secondary">Our
                            Satisified Customers</h2>
                    </div>
                </div>
                <div class="row border-responsive">
                    <div class="col-md-2 col-lg-2 mb-4 mb-lg-0 " data-aos="fade-up" data-aos-delay=""></div>

                    <div class="col-md-3 col-lg-3 mb-4 mb-lg-0 border-right" data-aos="fade-up" data-aos-delay="">
                        <div class="text-center">
                            <span
                                class="flaticon-money-bag-with-dollar-symbol display-4 d-block mb-3 text-primary"></span>
                            <h3 class="text-uppercase h4 mb-3">New Users</h3>
                            <div class="col-lg-6">
                                <div class="counter">
                                    <span class="number" data-number="78">0</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-lg-3 mb-4 mb-lg-0 border-right" data-aos="fade-up" data-aos-delay="">
                        <div class="text-center">
                            <span
                                class="flaticon-money-bag-with-dollar-symbol display-4 d-block mb-3 text-primary"></span>
                            <h3 class="text-uppercase h4 mb-3">Added Today</h3>
                            <div class="col-lg-6">
                                <div class="counter">
                                    <span class="number" data-number="20">0</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-lg-3 mb-4 mb-lg-0" data-aos="fade-up" data-aos-delay="">
                        <div class="text-center">
                            <span
                                class="flaticon-money-bag-with-dollar-symbol display-4 d-block mb-3 text-primary"></span>
                            <h3 class="text-uppercase h4 mb-3">Total Users</h3>
                            <div class="col-lg-6">
                                <div class="counter">
                                    <span class="number" data-number="125">0</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- END OF COUNTER NUMBER -->
<!-- start Our mission -->
<div class="well2 bg-dark">
    <div class="site-wrap">
        <div class="site-section section-counter"></div>
        <div class="site-section first-section">
            <div class="container">
                <div class="barner mb-2">
                    <div class="col-md-12 text-center" data-aos="fade"> <br>
                        <h2 class="site-section-heading text-uppercase text-center font-secondary">
                            afonete - The Future Of Internet user</h2>
                        <p class="pragraph">
                            We are an innovator technology company that building massive infrastructure
                            project, which combines the innovation of the web3 development and
                            blockchain technology where everybody deserves a fair chance for success
                            and Showing people that there is more than one path to success in
                            life with and become successful.</p>

                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<!-- End Our mission -->
<!-- start features section -->
<div class="well3  ">
    <div class="site-wrap">

        <div class="site-section first-section">
            <div class="container">
                <div class="row mb-2">
                    <div class="col-md-12 text-center" data-aos="fade"> <br>
                        <h6 class="site-section-heading text-uppercase text-center font-secondary"> Take a look
                            for yourself,
                            and find out which products best fit your personal goals and start growing
                            your own business today!</h6>
                        <h2 class="site-section-heading text-center">Mainly feature </h2>
                    </div>

                </div>

            </div>
        </div>
    </div>
</div>
</li>
<li>
    <p>For each referral that becomes upgrade you will earn a commission 10% </p>
</li>
<li>

    <!-- End features section -->

    <!-- Hero Section End -->
    </div>

    </div>
    <div class="col-md-3 col-lg-3 mb-4 mb-lg-0 border-right" data-aos="fade-up" data-aos-delay="">
        <div class="  text-center ">
            <span class="flaticon-money-bag-with-dollar-symbol display-4 d-block mb-3 text-primary"></span>
            <br><br>
            <div class="container" id="fear">
                <div class="fear">
                    <h3>Fear of lose</h3>
                </div><br>
                <div class="fear">
                    <h3>Eshop</h3>
                </div><br>
                <div class="fear">
                    <h3> investement & Trading</h3>
                </div><br>
                <div class="fear">
                    <h3>Transfer</h3>
                </div><br>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3 mb-6 mb-lg-0 border-right" data-aos="fade-up" data-aos-delay="">
        <div class="text-center">
            <span class="flaticon-money-bag-with-dollar-symbol display-4 d-block mb-3 text-primary"></span>


            <img src="{{asset('assets/front/img/sm-banner1-feature.jpg')}}" width="750px" id="feim" alt="">
        </div>
    </div>

    <div class="col-md-4 col-lg-4 mb-8 mb-lg-0" data-aos="fade-up" data-aos-delay="">
        <div class=" text-center">
            <span class="flaticon-money-bag-with-dollar-symbol display-4 d-block mb-3 text-primary"></span>
            <br><br>
            <div class="exch">
                <h3>Exchange</h3>
            </div> <br>
            <div class="exch">
                <h3>Crypto_Loan</h3>
            </div> <br>
            <div class="exch">
                <h3>Chat
            </div>
            </h3><br>
        </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    <!-- End features section -->
    <div class="well4 ">
        <div class="site-wrap">
            <div class="site-section section-counter"></div>
            <div class="site-section first-section">
                <div class="container">
                    <div class="barner7 row mb-2">

                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- Hero Section End -->
    </div>

    @include('home.include.footer')
    </div>