<div>
        @include('home.include.user-base')

<div class="breadcrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <h2>About Us</h2>
                        <p >Afonete is a unique innovative a next generation affiliate
                             system, aims to connecting  companies  are sure to reach the 
                             right audience with  clients and where we help millions of 
                             people transform their lives that can benefit each other of 
                             happy customers wanting to gain access to these amazing 
                             platforms.</p>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section End -->

    <!-- About Us Page Section Begin -->
    <section class="aboutus-page-section spad">
     
                <div class="row">
                    <div class="col-lg-6">
                        <div class="breadcrumb-text" style="margin-top:-50px;">
                            
                            <p>
                                Afonete  bridges the gap between traditional marketing and the digital marketing in world. Afonete  
                                offers innovative business solutions which enable merchants from around the world to sell their 
                                products/service for latest technology , interacting with a global audience of next generation 
                                affiliate platform
                            </p><br>
                          <p>
                                <!--<h2 style="font-size: 20px; font-weight: bold;">-->
 We are combining traditional marketing, AI marketing, social media marketing, 
  and affiliate marketing opportunities to promote your product and service. This helps 
  provide high levels of residual income for all our affiliate members. We help you spread
  potential information to everyone, anywhere in the world.
</p>
                        </div>                
                    </div>
               
                   <style> 
                   #nn1{
                       display:none;
                   }
                   #nn{
                       
                             width:450px;
                           height:300px;
                           margin-left:200px;
                           margin-top:-120px;
                           display:block;
                          }
                    @media screen and (max-width:867px){
                              #nn1{
                           /*width:550px;*/
                           /*height:400px;*/
                           /*margin-left:130px;*/
                           /*margin-top:-120px;*/
                           display:block;
                       }
                       #nn{
                           display:none;
                       }
                          
                       }
                  
                   </style>
                   <div id="nn">
  <img src="assets/front/img/sm-banner1.jpg" alt="fail" style="width: 100%; border-radius:10px; height: auto;">
</div>
                <div id="nn1">
  <img src="assets/front/img/sm-banner1.jpg" alt="fail" style="width: 100%; border-radius:10px; height: auto;">
</div>


                    <div class="col-lg-12">
                        <div class="ap-title">
                        <!-- font-size: 44px;
	color: #19191a;
	margin-bottom: 18px; --><br><br><br><br>
                            <h3 style="font-size:20px;margin-bottom: 18px;" >A fonete  have created a unique solutions system for global community of people who love innovative technologies, blockchain technologies
                             and opened access for all people to benefit from a system we can implement
                              future innovations today  which just<br> a few years ago was only accessible
                              for big companies.</h3>
                            
                        </div>
                </div>
            </div>
        </div>
    </section>

@include('home.include.footer')
 </div>